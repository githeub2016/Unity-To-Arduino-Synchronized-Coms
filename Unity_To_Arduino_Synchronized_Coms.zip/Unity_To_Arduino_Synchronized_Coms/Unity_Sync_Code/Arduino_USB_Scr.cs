using System;//for { Environment.NewLine}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

//---
//Y-Spectrum-2 (YouTube)
//this code is free to use as you wish!
//-------

public class Arduino_USB_Scr : MonoBehaviour
{
    private SerialPort serialPORT;
    private string Current_Data_Transfer_Confirmation_Marker = ""; 
    private int Servo_Data_Read_Write_Status = 0;
    private int Number_Of_COM_Ports = 0;
    private string[] the_com_name;
    private bool Arduino_Configuration_Done = false;
    private char[] Collect_Digits_Str;
    private string Servo_test_Data_To_Send = "";
    private int[] Nums_Between_0_to_180;//this takes Chars in its array index
    private string[] Alphabets_Between_0_to_180;
    private string Data_Recieved_From_Arduino = "";
    private float The_Smooth_INC_Val = 0;
    private float Go_To_Value = 0;
    private float Go_To_Speed_INC = 0;
    private bool Do_Once = false;
    private int v_0_180 = 0;
    private int Nothing_Recieved_Counter = 0;

    // Use this for initialization
    void Start()
    {

        //set space to collect the available port names
        the_com_name = new string[4];
        //first set number of ports to zero
        Number_Of_COM_Ports = 0;
        //collect the available ports (the names)
        foreach (string mysps in SerialPort.GetPortNames())
        {
            //collect com ports (only 2)
            if(Number_Of_COM_Ports < 2)
            {
                //dont use "COM1"
                if (mysps != "COM1")
                {
                    //count the ports
                    Number_Of_COM_Ports = Number_Of_COM_Ports + 1;
                    //collec the ports
                    the_com_name[Number_Of_COM_Ports] = mysps;
                    //leave the loop if 2 or more ports have been collected
                    if (Number_Of_COM_Ports >= 2)
                    {
                        break;
                    }
                    //---------------------------
                }
            }
            //-------------------------------------------
        }
        //------------------------------

        //if there are com ports found
        if (Number_Of_COM_Ports > 0)
        {           
            //show number of ports found
            print("num ports found: " + Number_Of_COM_Ports);

            //Just select the first port and set it up with baudrate of 9600 (Arduino Friendly rate)
            int Port_Selected = 1;
            serialPORT = new SerialPort("\\\\.\\" + the_com_name[Port_Selected], 9600);
            //first set to false
            Arduino_Configuration_Done = true;
            //check that the port is not already open
            if (!serialPORT.IsOpen)
            {
                //say that the port is being opened
                print("Opening " + the_com_name[Port_Selected] + ", baud 9600");//arduino uno baudrate(9600);Adafruit Metro M0 Express baudrate(115200)14400;
                //Open the port
                serialPORT.Open();
                //set coms settings
                serialPORT.ReadTimeout = 100;
                serialPORT.Handshake = Handshake.None;
                //see if it is succesfully opened then say it is opened
                if (serialPORT.IsOpen)
                {
                    //set to true to enable sending data to arduino (in update loop)
                    Arduino_Configuration_Done = true;
                    //say port is open
                    print("Open" + the_com_name[Port_Selected]);
                }
            }

        }
        else
        {
            //say no ports found if Number_Of_COM_Ports = 0 (or less than 0)
            print("No ports found.. ");
        }
        //------------------------------------------------------------------------

    }




    //format the number data to send to arduino (to drive servos (3 digits max per servo cause these servos only need 0 to 180)
    private string Collect_And_Format_Numbers_Data_To_Send_To_Arduino(int S1, int S2, int S3, int S4, int S5, int S6, int S7, int S8, int S9, int S10, int S11, int S12, int S13, int S14, int S15, int S16)
    {
        string tmp_Svdata_OUT = "";

        //collect the values into an array
        int[] Servo_Data_Array = new int[] { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15, S16 };
        int i = 0;
        string Save_3_Digit_STR = "";
        int Save_3_Digit_Value = 0;

        //set the max 3 digit number allowed to send to Arduino
        int Max_3_Digit_Value_To_Send = 999;


        //check and format all input numbers
        for (i = 0; i < Servo_Data_Array.Length; i++)
        {
            //collect a value
            Save_3_Digit_Value = Servo_Data_Array[i];
            //see if it more than Max_3_Digit_Value_To_Send
            if (Save_3_Digit_Value > Max_3_Digit_Value_To_Send)
            {
                //set it to 999 if its more than 999
                Save_3_Digit_Value = Max_3_Digit_Value_To_Send;
            }
            //collect the value into a string and format it with 2 leading zeros so 9 = 009 etc
            Save_3_Digit_STR = $"{Save_3_Digit_Value:000}";

            //add them to the string
            tmp_Svdata_OUT = tmp_Svdata_OUT + Save_3_Digit_STR;

        }
        //-------------------------------


        //show me the whole values after the encoding 
        //print(tmp_Svdata_OUT);
        //show me the len
        //print("sent data Lenght: " + tmp_Svdata_OUT.Length);


        return tmp_Svdata_OUT;
    }



    //function to do smooth increments back and forth from 0 to 180
    private void Do_Smooth_Increments_From_0_to_180()
    {

        float offsetVAL = 8;

        //set start Go to value (do this only once)
        if (Do_Once == false)
        {
            //set start Go to value            
            Go_To_Value = 180 + offsetVAL;
            //say done
            Do_Once = true;
        }
        //--------------------------------------

        //to do a lerped blinking of the turret muzzle light 
        Go_To_Speed_INC = 4.5f;// 6.5f;

        //increment to the set value
        The_Smooth_INC_Val = Mathf.Lerp(The_Smooth_INC_Val, Go_To_Value, Go_To_Speed_INC * Time.deltaTime);


        //if higher then make it zero
        if (The_Smooth_INC_Val > 180)
        {
            Go_To_Value = 0 - offsetVAL;//5
            The_Smooth_INC_Val = 180;
        }
        //if less than zero then set higher
        if (The_Smooth_INC_Val < 0)
        {
            Go_To_Value = 180 + offsetVAL;
            The_Smooth_INC_Val = 0;
        }
        //------------------------------------------------------------

        //convert to int
        v_0_180 = (int)The_Smooth_INC_Val;
        //test print values
        //print("test print Val: " + v_0_180);
    }



    //for servo simulated joints move using angles
    private void Drive_Servos_Using_Angles_Check()
    {
        //generate value 0 to 180 in increments to send
        Do_Smooth_Increments_From_0_to_180();
        //collect and format the input number (Data to send to Arduino)(3 digits max each)(just using same value for all servos for testing)
        Servo_test_Data_To_Send = Collect_And_Format_Numbers_Data_To_Send_To_Arduino(v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180, v_0_180);
        //send and recieve data from Arduino
        Send_And_Recieve_Data_From_Arduino(Servo_test_Data_To_Send);
    }








    // Update is called once per frame
    void Update()
    {


        //if Arduino_Configuration_Done then start sending and recieving data from Arduino
        if (Arduino_Configuration_Done == true)
        {
            Drive_Servos_Using_Angles_Check();
        }
        //--------------------------------------------------------------------

    }






    private int Send_And_Recieve_Data_From_Arduino(string Servo_Data_IN)
    {

        string tmp_Combine_Data_To_Send = "";
        string tmp_Data_Recieved = "";
        string Confirmation_Marker_Recieved = "";
        int Servo_Arduino_Confirmed_Data_Recieved = 0;
        int resendCound = 0;

        //if the port is open then send data
        if (serialPORT.IsOpen)
        {
            //send data
            if (Servo_Data_Read_Write_Status == 0)
            {

                //alternate between the transfer confirmation symbol (to be returned from arduino to say data is gotten)
                if (Current_Data_Transfer_Confirmation_Marker == "" || Current_Data_Transfer_Confirmation_Marker == "b")
                {
                    Current_Data_Transfer_Confirmation_Marker = "a";
                }
                else
                {
                    Current_Data_Transfer_Confirmation_Marker = "b";
                }
                //-------------------------------------------------------------------------------------------

                //colect data to write (no more than 64 bytes (cause Arduino cant handle more than 64) (for arduino code its set by arduino MAX_MESSAGE_LENGTH))
                tmp_Combine_Data_To_Send = Current_Data_Transfer_Confirmation_Marker + Servo_Data_IN;// "123123123123123123123123123123123123123123123123";


                //WriteLine Writes the specified string and adds the NewLine(end of data marker) value to the output buffer (so arduino knows when data it recieved is complete).
                serialPORT.WriteLine(tmp_Combine_Data_To_Send);
                //print("data write....");

                //go to listen for arduino response
                Servo_Data_Read_Write_Status = 1;
            }
            //-------------------------------------------------------------

            //recieve data
            if (Servo_Data_Read_Write_Status == 1)
            {
                try
                {

                    //while loop to wait till arduino data returns
                    while (Servo_Arduino_Confirmed_Data_Recieved == 0)
                    {
                        //Reads up to the NewLine value in the input buffer (the NewLine character is not included).
                        tmp_Data_Recieved = serialPORT.ReadLine();
                        //set confirmation recieved to null (each time so it can be collected fresh each time below after checking)
                        Confirmation_Marker_Recieved = "";

                        //check the confirmation from arduino
                        if (tmp_Data_Recieved != "")
                        {
                            //print("Servo Arduino recieved: " + tmp_Data_Recieved);

                            //make sure data is enough
                            if (tmp_Data_Recieved.Length > 1)
                            {
                                //collect the first character recieved from Arduino (should be the Data_Transfer_Confirmation_Marker (format by Arduino IDE code))
                                Confirmation_Marker_Recieved = tmp_Data_Recieved.Substring(0, 1);
                                //check that the confirmation from arduino matches the one send from Unity
                                if (Confirmation_Marker_Recieved == Current_Data_Transfer_Confirmation_Marker)
                                {
                                    //collec the data from arduino (like maybe sensor data)
                                    Data_Recieved_From_Arduino = tmp_Data_Recieved;
                                    //Enable go to send more data from Unity
                                    Servo_Data_Read_Write_Status = 0;
                                    Servo_Arduino_Confirmed_Data_Recieved = 1;
                                    //just print a test to compare what we sent to what we recieved (number values should match)
                                    print("From Arduino: " + Data_Recieved_From_Arduino + " > Unity: " + v_0_180);
                                }
                                //---------------------------------------------
                            }
                            else//if nothing is recieved from Arduino (this part is not really nessesary)
                            {
                                //count how many times nothing is received
                                Nothing_Recieved_Counter = Nothing_Recieved_Counter + 1;
                                //if nothing revieved too many times then leave
                                if (Nothing_Recieved_Counter > 200)
                                {
                                    Nothing_Recieved_Counter = 0;
                                    print("No Data Recieved from Arduino, maybe check Arduino IDE Code");
                                    //disable data sending to Arduino cause the Arduino is not configured
                                    Arduino_Configuration_Done = false;
                                    //leave the loop to stop waiting for the Arduino data (or it will be stuck here)
                                    break;
                                }
                                //--------------------------------------------
                            }
                        }
                        //-------------------------------------------------
                    }


                }
                //handle the timeout exception
                catch (TimeoutException)
                {
                    Servo_Arduino_Confirmed_Data_Recieved = 3;

                    resendCound = resendCound + 1;
                    if(resendCound > 200)
                    {
                        resendCound = 0;
                        //go to send more data
                        Servo_Data_Read_Write_Status = 0;
                        Servo_Arduino_Confirmed_Data_Recieved = 0;
                    }
                    print("errooro");
                }

            }
            //--------------------------------------------
        }

        return Servo_Arduino_Confirmed_Data_Recieved;
    }





    //to close the port (to free the port for other programs like Arduino IDE)
    void OnApplicationQuit()
    {
        //if there are com ports found
        if (Number_Of_COM_Ports > 0)
        {
            //see if port is open
            if (serialPORT.IsOpen)
            {
                //close it
                serialPORT.Close();
                print("closed port");
            }
            //----------------------------------
        }
        //---------------------------------------------------------
    }
}